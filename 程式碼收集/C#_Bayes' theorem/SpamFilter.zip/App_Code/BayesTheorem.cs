using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.OleDb;
using System.Data.SqlClient;
/// <summary>
/// Summary description for BayesTheorem
/// </summary>
/// 
namespace ats.BayesTheorem
{
    public class BayesTheorem
    {
        public static SqlConnection getSqlConn()
        {
            ConnectionStringSettingsCollection connections =
            ConfigurationManager.ConnectionStrings;

            string SqlConn = connections["DBASE"].ConnectionString;

            SqlConnection con = new SqlConnection(SqlConn);
            try
            {
                con.Open();
            }
            catch (Exception)
            { }
            return con;

        }
        public static String TotalNonSpam()
        {
            using (SqlConnection dbConn = getSqlConn())
            {
                String sql = "SELECT SUM(nonSpam) From SpamTable";
                SqlCommand command = new SqlCommand(sql, dbConn);
                Object item = command.ExecuteScalar();
                if (item != null)
                    return item.ToString();
                else return "";
            }
        }
        public static String TotalSpam()
        {
            using (SqlConnection dbConn = getSqlConn())
            {
                String sql = "SELECT SUM(Spam) From SpamTable";
                SqlCommand command = new SqlCommand(sql, dbConn);
                Object item = command.ExecuteScalar();
                if (item != null)
                    return item.ToString();
                else return "";
            }
        }
        public static String FindNonSpamWord(String word)
        {
            using (SqlConnection dbConn = getSqlConn())
            {
                String sql = "SELECT nonSpam From SpamTable Where word=@name";
                SqlCommand command = new SqlCommand(sql, dbConn);
                command.Parameters.Add(new SqlParameter("@name", SqlDbType.VarChar));
                command.Parameters["@name"].Value = word;
                Object item = command.ExecuteScalar();
                if (item != null)
                    return item.ToString();
                else return "";
            }
        }
        public static String FindSpamWord(String word)
        {
            using (SqlConnection dbConn = getSqlConn())
            {
                String sql = "SELECT Spam From SpamTable Where word=@name";
                SqlCommand command = new SqlCommand(sql, dbConn);
                command.Parameters.Add(new SqlParameter("@name", SqlDbType.VarChar));
                command.Parameters["@name"].Value = word;
                Object item = command.ExecuteScalar();
                if (item != null)
                    return item.ToString();
                else return "";
            }
        }
    }
}
