using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ats.BayesTheorem;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int TotalNonSpam = Convert.ToInt32(BayesTheorem.TotalNonSpam());
        int TotalSpam = Convert.ToInt32(BayesTheorem.TotalSpam());

        int totalCount = TotalNonSpam + TotalSpam;

        Double PercentTotalNonSpam = TotalNonSpam / (double)totalCount;
        Double PercentTotalSpam = TotalSpam / (double)totalCount;

        //Give output of analysis from database
        Label1.Text = TotalNonSpam.ToString();
        Label2.Text = TotalSpam.ToString();
        Label5.Text = totalCount.ToString();

        Label3.Text = PercentTotalNonSpam.ToString();
        Label4.Text = PercentTotalSpam.ToString();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String inputContent = TextBox1.Text;
        inputContent = inputContent.Replace("\t", "");
        inputContent = inputContent.Replace("\n", "");
        inputContent = inputContent.Replace(",", "");
        inputContent = inputContent.Replace(".", "");
        inputContent = inputContent.Replace(";", "");
        inputContent = inputContent.Replace(":", "");
        inputContent = inputContent.Replace("?", "");
        inputContent = inputContent.Replace("!", "");
        inputContent = inputContent.Replace("&", "");

        char seperator = ' ';
        String[] words = inputContent.Split(seperator);
        int CountWords = words.Length;
        //keep P(score) and multiply
        double SpamPercent = 1.0;
        double NonSpamPercent = 1.0;
        
        //look for percentage of word in nonspam
        for (int i = 0; i < CountWords; i++)
        {
            String thisword = words[i];
            String DBaseValue = (BayesTheorem.FindNonSpamWord(thisword));
            if (DBaseValue == "")
            {
                //Perform Laplacin or just equal to 1
                DBaseValue = "1";
            }
           NonSpamPercent = NonSpamPercent * (Convert.ToDouble(DBaseValue) / Convert.ToInt32(BayesTheorem.TotalNonSpam()));
            
        }
        //look for percentage of word in spam
        for (int i = 0; i < CountWords; i++)
        {
            String thisword = words[i];
            String DBaseValue = (BayesTheorem.FindSpamWord(thisword));
             if (DBaseValue == "")
            {
                //Perform Laplacin or just equal to 1
                DBaseValue = "1";
            }
                SpamPercent = SpamPercent * (Convert.ToDouble(DBaseValue) / Convert.ToInt32(BayesTheorem.TotalSpam()));
        }

        //get P(mailType).P(Word | MailType) for NonSpam
        SpamPercent = SpamPercent * Convert.ToDouble(Label4.Text) * 100;
        //get P(mailType).P(Word | MailType) for Spam
        NonSpamPercent = NonSpamPercent * Convert.ToDouble(Label3.Text) * 100;

        //Show results in table
        Label6.Text = NonSpamPercent.ToString();
        Label7.Text = SpamPercent.ToString();

        if (SpamPercent > NonSpamPercent)
            Label8.Text = "Spam Mail";
        else Label8.Text = "NonSpam Mail";

        //insert words or add new word and count for future training
        //TO DO: .....

    }
}
